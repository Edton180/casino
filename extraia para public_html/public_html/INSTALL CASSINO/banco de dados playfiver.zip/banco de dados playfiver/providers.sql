-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Tempo de geração: 19/10/2024 às 16:18
-- Versão do servidor: 8.0.39-0ubuntu0.22.04.1
-- Versão do PHP: 8.1.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `ONDAGAMES_CHINESA`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `providers`
--

CREATE TABLE `providers` (
  `id` bigint UNSIGNED NOT NULL,
  `cover` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT '1',
  `rtp` bigint DEFAULT '90',
  `views` bigint DEFAULT '1',
  `distribution` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'play_fiver',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

--
-- Despejando dados para a tabela `providers`
--

INSERT INTO `providers` (`id`, `cover`, `code`, `name`, `status`, `rtp`, `views`, `distribution`, `created_at`, `updated_at`) VALUES
(2, NULL, 'PRAGMATIC', 'PRAGMATIC', 1, 50, 1, 'play_fiver', '2024-04-16 02:51:14', '2024-05-09 01:18:26'),
(3, NULL, 'SPRIBE', 'SPRIBE', 1, 50, 1, 'play_fiver', '2024-04-16 14:38:13', '2024-06-08 00:39:45'),
(9, NULL, 'NETENT', 'NETENT', 1, 50, 1, 'play_fiver', '2024-04-16 15:30:19', '2024-05-06 17:13:19'),
(13, NULL, 'DREAMTECH', 'DREAMTECH', 1, 50, 1, 'play_fiver', '2024-04-16 17:48:28', '2024-05-09 00:55:00'),
(1, NULL, 'PGSOFT', 'PGSOFT', 1, 50, 1, 'play_fiver', '2024-05-02 13:49:33', '2024-10-09 18:48:34'),
(4, NULL, 'GALAXSYS', 'GALAXSYS', 1, 50, 1, 'play_fiver', '2024-05-02 14:24:20', '2024-05-09 00:54:52'),
(5, NULL, 'NOVAMATIC', 'NOVAMATIC', 1, 50, 1, 'play_fiver', '2024-05-02 14:42:14', '2024-05-06 17:07:08'),
(6, NULL, 'MICROGAMING', 'MICROGAMING', 1, 50, 1, 'play_fiver', '2024-05-02 14:51:14', '2024-05-06 17:09:52'),
(7, NULL, 'HABANERO', 'HABANERO', 1, 50, 1, 'play_fiver', '2024-05-02 16:15:37', '2024-05-06 17:10:28'),
(8, NULL, 'PLAYNGO', 'PLAYNGO', 1, 50, 1, 'play_fiver', '2024-05-02 16:22:19', '2024-05-06 17:11:29'),
(10, NULL, 'PLAYSON', 'PLAYSON', 1, 50, 1, 'play_fiver', '2024-05-02 16:49:33', '2024-05-06 17:14:01'),
(11, NULL, 'PRAGMATICLIVE', 'PRAGMATICLIVE', 1, 50, 1, 'play_fiver', '2024-05-02 17:53:24', '2024-05-06 17:15:46'),
(12, NULL, 'TOPTREND', 'TOPTREND', 1, 50, 1, 'play_fiver', '2024-05-02 17:58:52', '2024-05-06 17:17:12'),
(15, NULL, 'BOOONGO', 'BOOONGO', 1, 50, 1, 'play_fiver', '2024-05-03 14:18:11', '2024-05-09 01:19:22'),
(14, NULL, 'EVOPLAY', 'EVOPLAY', 1, 50, 1, 'play_fiver', '2024-05-03 14:25:49', '2024-07-15 20:29:21'),
(16, NULL, 'CQ9', 'CQ9', 1, 50, 1, 'play_fiver', '2024-05-23 20:48:08', '2024-05-23 21:24:22'),
(17, NULL, 'REELKINGDOM', 'REELKINGDOM', 1, 50, 1, 'play_fiver', '2024-05-29 18:30:55', '2024-05-29 18:30:55'),
(18, NULL, 'EVOLUTION', 'EVOLUTION', 1, 50, 1, 'play_fiver', '2024-06-17 17:05:10', '2024-06-17 17:05:10'),
(11125, NULL, 'TESTE', 'TESTE', 1, 90, 1, 'play_fiver', '2024-08-28 00:50:53', '2024-08-28 00:50:53'),
(11126, NULL, 'JETX', 'JETX', 1, 90, 1, 'play_fiver', '2024-09-24 20:59:08', '2024-09-24 20:59:08');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `providers`
--
ALTER TABLE `providers`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `providers`
--
ALTER TABLE `providers`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11127;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
